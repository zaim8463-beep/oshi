package com.example.touchassist

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.Toast
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import java.util.Locale

/** شاشة الإعدادات: نفس ترتيب Settings ‹ Accessibility ‹ Touch ‹ AssistiveTouch في iOS. */
class MainActivity : Activity() {

    private lateinit var content: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(16), dp(24), dp(16), dp(32))
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.parseColor("#F2F2F7"))
        scroll.addView(content)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun serviceEnabled(): Boolean {
        if (AssistService.instance != null) return true
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains("$packageName/") && s.contains("AssistService")
    }

    private fun secs(ms: Int) = String.format(Locale.US, "%.2f", ms / 1000f)

    private fun render() {
        content.removeAllViews()
        val gestures = Store.loadGestures(this)
        val enabled = serviceEnabled()

        content.addView(text("اللمس المساعد", 30f, true))

        if (!enabled) {
            val c = card()
            c.addView(text("⚠️ لازم تفعّل خدمة إمكانية الوصول عشان الزر يشتغل", 15f, true))
            c.addView(
                text(
                    "إعدادات إمكانية الوصول ← التطبيقات المُثبّتة ← اللمس المساعد ← تشغيل.\n" +
                        "لو الخيار رمادي (أندرويد 13+): إعدادات التطبيق ← ⋮ ← السماح بالإعدادات المقيّدة.",
                    13f, false
                )
            )
            c.addView(button("فتح إعدادات إمكانية الوصول") {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            })
            content.addView(c)
        }

        // ── المفتاح الرئيسي
        val mainCard = card()
        val sw = Switch(this)
        sw.text = "اللمس المساعد"
        sw.textSize = 17f
        iosSwitch(sw)
        sw.isEnabled = enabled
        sw.isChecked = Store.buttonEnabled(this)
        sw.setOnCheckedChangeListener { _, checked ->
            Store.setButtonEnabled(this, checked)
            AssistService.instance?.refreshButton()
        }
        mainCard.addView(sw)
        content.addView(mainCard)
        content.addView(note("يسمح لك اللمس المساعد باستخدام الجهاز بسهولة إذا كان لديك صعوبة في لمس الشاشة أو الضغط على الأزرار."))

        // ── تخصيص قايمة المستوى الأعلى
        val topCard = card()
        topCard.addView(navRow("تخصيص قائمة المستوى الأعلى", "${Store.topMenu(this).size}", false) {
            startActivity(Intent(this, TopMenuActivity::class.java))
        })
        content.addView(topCard)

        // ── إجراءات مخصصة
        content.addView(header("إجراءات مخصصة"))
        val act = card()
        act.addView(navRow("ضغطة واحدة", Actions.label(this, Store.getAction(this, "single")), false) { pickAction("single") })
        act.addView(divider())
        act.addView(navRow("ضغط مرتين", Actions.label(this, Store.getAction(this, "double")), false) { pickAction("double") })
        act.addView(divider())
        act.addView(navRow("ضغط مطول", Actions.label(this, Store.getAction(this, "long")), false) { pickAction("long") })
        for ((tid, tname) in extraCatalog) {
            if (Store.extraTriggers(this).contains(tid) || Store.getAction(this, tid) != "none") {
                act.addView(divider())
                act.addView(navRow(tname, Actions.label(this, Store.getAction(this, tid)), false) { pickAction(tid) })
            }
        }
        act.addView(divider())
        act.addView(navRow("إضافة أمر جديد…", "", true) { addCommand() })
        content.addView(act)
        content.addView(note("إجراءات مخصصة تمكنك من التفاعل مع أيقونة اللمس المساعد دون فتح القائمة. تقدر تضيف أوامر زيادة (ضغط 3 مرات، سحب سريع بأي اتجاه) وتربطها بأي إجراء. لو عرّفت سحب سريع: الأيقونة بتتحرك لو ضغطت عليها لحظة قبل ما تسحبها."))

        val tm = card()
        tm.addView(text("مهلة الضغط مرتين: ${secs(Store.doubleTapMs(this))} ث", 15f, false))
        tm.addView(seek(0, 1000, Store.doubleTapMs(this)) {
            Store.setDoubleTapMs(this, it)
            AssistService.instance?.refreshButton()
            render()
        })
        tm.addView(text("مدة الضغط المطول: ${secs(Store.longPressMs(this))} ث", 15f, false))
        tm.addView(seek(0, 2000, Store.longPressMs(this)) {
            Store.setLongPressMs(this, it)
            AssistService.instance?.refreshButton()
            render()
        })
        content.addView(tm)

        // ── إيماءات مخصصة
        content.addView(header("إيماءات مخصصة"))
        val gCard = card()
        for ((i, g) in gestures.withIndex()) {
            if (i > 0) gCard.addView(divider())
            gCard.addView(navRow(g.name, "", false) {
                val i2 = Intent(this, GestureEditActivity::class.java)
                i2.putExtra("id", g.id)
                startActivity(i2)
            })
        }
        if (gestures.isNotEmpty()) gCard.addView(divider())
        gCard.addView(navRow("إنشاء إيماء جديد…", "", true) {
            startActivity(Intent(this, RecordActivity::class.java))
        })
        content.addView(gCard)
        content.addView(
            note("تسمح لك الإيماءات المخصصة بتسجيل الإيماءات التي يمكن تنشيطها من \"مخصص\" في \"القائمة\".")
        )
        content.addView(
            note(
                "طريقة الماكرو: اضغط الزر ← مخصص ← اختار الإيماءة ← هتظهر كور خضرا كبيرة، حرّكها فوق المكان اللي عايزه وسيبها " +
                    "فتتحول لكورة واحدة ثابتة مبتتحركش. بعدها اضغط ضغطة مطوّلة (أو ضغطتين) على الزر عشان تتنفّذ في مكان الكورة، " +
                    "وضغطة واحدة عشان تختفي. تقدر تربط الإيماءة بالضغط المطوّل/المزدوج من \"إجراءات مخصصة\"."
            )
        )

        // ── تعتيم عند الخمول + الحجم
        content.addView(header("تعتيم عند الخمول"))
        val look = card()
        look.addView(text("${Store.idleOpacity(this)}%", 15f, false))
        look.addView(seek(15, 100, Store.idleOpacity(this)) {
            Store.setIdleOpacity(this, it)
            AssistService.instance?.refreshButton()
            render()
        })
        look.addView(text("حجم الزر", 15f, false))
        look.addView(seek(30, 90, Store.btnSize(this)) {
            Store.setBtnSize(this, it)
            AssistService.instance?.refreshButton()
        })
        content.addView(look)

        // ── الكورة
        content.addView(header("الكورة"))
        val ball = card()
        ball.addView(text("لون الكورة", 15f, false))
        ball.addView(colorRow())
        ball.addView(navRow("لون مخصص (HEX)", "#RRGGBB", false) { hexDialog() })
        ball.addView(divider())
        ball.addView(text("حجم الكورة: ${Store.ballDp(this)}", 15f, false))
        ball.addView(seek(40, 120, Store.ballDp(this)) {
            Store.setBallDp(this, it)
            render()
        })
        content.addView(ball)
        content.addView(note("الكورة مبتاخدش لمس خالص: لمسك بيوصل للتطبيق اللي تحتها. باقي إعدادات الكورة (مدة الضغط المطوّل 0–10 ثانية، مدة النقر، مدة السحب، والأهداف المكتوبة) بتتظبط لكل إيماءة من تعديل الإيماءة، وبتتنفّذ على مكان الكورة لما تتحكم من أيقونة اللمس المساعد."))

        // ── خيارات إضافية
        content.addView(header("خيارات"))
        val opt = card()
        val canWrite = Settings.System.canWrite(this)
        opt.addView(
            navRow(
                "تدوير الشاشة / قفل التدوير",
                if (canWrite) "مسموح ✅" else "محتاج صلاحية",
                false
            ) {
                if (!canWrite) {
                    startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
                }
            }
        )
        opt.addView(divider())
        opt.addView(
            navRow(
                "الظهور فوق التطبيقات الأخرى",
                if (Settings.canDrawOverlays(this)) "مسموح ✅" else "اسمح",
                false
            ) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        )
        opt.addView(divider())
        opt.addView(navRow("إبقاء الميزة شغالة بعد إغلاق التطبيق", "البطارية", false) { keepAlive() })
        content.addView(opt)
        content.addView(
            note(
                "الميزة بتشتغل من خدمة إمكانية الوصول، فتقدر تقفل التطبيق والزر يفضل ظاهر. لو جهازك بيقفل الخدمة لما تمسح التطبيق " +
                    "من الأخيرة: اختار \"بدون قيود\" للبطارية، وفعّل التشغيل التلقائي (Autostart) لو موجود، وثبّت التطبيق في قائمة الأخيرة."
            )
        )
    }

    private fun colorRow(): View {
        val cur = Store.ballColor(this)
        val colors = intArrayOf(
            Color.rgb(57, 255, 20), Color.rgb(10, 132, 255), Color.rgb(255, 59, 48),
            Color.rgb(255, 214, 10), Color.rgb(255, 159, 10), Color.rgb(191, 90, 242),
            Color.rgb(100, 210, 255), Color.rgb(255, 45, 85), Color.rgb(255, 255, 255)
        )
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(0, dp(6), 0, dp(6))
        for (col in colors) {
            val dot = View(this)
            val d = GradientDrawable()
            d.shape = GradientDrawable.OVAL
            d.setColor(col)
            d.setStroke(if (col == cur) dp(3) else dp(1), if (col == cur) Color.parseColor("#007AFF") else Color.parseColor("#C7C7CC"))
            dot.background = d
            val lp = LinearLayout.LayoutParams(dp(34), dp(34))
            lp.setMargins(dp(4), dp(4), dp(4), dp(4))
            dot.setOnClickListener {
                Store.setBallColor(this, col)
                render()
            }
            row.addView(dot, lp)
        }
        val hs = HorizontalScrollView(this)
        hs.addView(row)
        return hs
    }

    private fun hexDialog() {
        val et = EditText(this)
        et.setSingleLine(true)
        et.hint = "#39FF14"
        AlertDialog.Builder(this)
            .setTitle("لون الكورة (HEX)")
            .setView(et)
            .setPositiveButton("حفظ") { _, _ ->
                try {
                    val raw = et.text.toString().trim()
                    val col = Color.parseColor(if (raw.startsWith("#")) raw else "#$raw")
                    Store.setBallColor(this, col or 0xFF000000.toInt())
                    render()
                } catch (_: Exception) {
                    Toast.makeText(this, "لون غير صحيح", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun keepAlive() {
        try {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        } catch (_: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (_: Exception) {
            }
        }
    }

    private val extraCatalog = listOf(
        "triple" to "ضغط 3 مرات",
        "quad" to "ضغط 4 مرات",
        "flick_up" to "سحب سريع لأعلى",
        "flick_down" to "سحب سريع لأسفل",
        "flick_left" to "سحب سريع لليسار",
        "flick_right" to "سحب سريع لليمين"
    )

    private fun addCommand() {
        val avail = extraCatalog.filter {
            !(Store.extraTriggers(this).contains(it.first) || Store.getAction(this, it.first) != "none")
        }
        if (avail.isEmpty()) {
            Toast.makeText(this, "كل الأوامر المتاحة مضافة", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("اختر نوع الأمر")
            .setItems(avail.map { it.second }.toTypedArray()) { _, w -> pickAction(avail[w].first) }
            .show()
    }

    private fun pickAction(trigger: String) {
        ActionPicker.show(this, "اختر الإجراء", false, Store.getAction(this, trigger)) { picked ->
            Store.setAction(this, trigger, picked)
            if (extraCatalog.any { it.first == trigger }) {
                if (picked == "none") Store.removeExtraTrigger(this, trigger) else Store.addExtraTrigger(this, trigger)
            }
            AssistService.instance?.refreshButton()
            render()
        }
    }

    // ───────────── مكوّنات الواجهة ─────────────

    private fun iosSwitch(s: Switch) {
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        s.trackTintList = ColorStateList(states, intArrayOf(Color.parseColor("#34C759"), Color.parseColor("#C7C7CC")))
        s.thumbTintList = ColorStateList.valueOf(Color.WHITE)
    }

    private fun navRow(label: String, value: String, blue: Boolean, onClick: () -> Unit): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(0, dp(12), 0, dp(12))
        val l = text(label, 16f, false)
        if (blue) l.setTextColor(Color.parseColor("#007AFF"))
        row.addView(l, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (value.isNotEmpty()) {
            val v = text(value, 14f, false)
            v.setTextColor(Color.parseColor("#8E8E93"))
            row.addView(v)
        }
        val chev = text("  ‹", 18f, false)
        chev.setTextColor(Color.parseColor("#C7C7CC"))
        row.addView(chev)
        row.setOnClickListener { onClick() }
        return row
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable()
        bg.setColor(Color.WHITE)
        bg.cornerRadius = dp(12).toFloat()
        c.background = bg
        c.setPadding(dp(14), dp(6), dp(14), dp(6))
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(8)
        c.layoutParams = lp
        return c
    }

    private fun header(t: String): TextView {
        val v = text(t, 13f, false)
        v.setTextColor(Color.parseColor("#6B6B70"))
        v.setPadding(dp(4), dp(18), 0, 0)
        return v
    }

    private fun note(t: String): TextView {
        val v = text(t, 12f, false)
        v.setTextColor(Color.parseColor("#6B6B70"))
        v.setPadding(dp(4), dp(6), dp(4), 0)
        return v
    }

    private fun divider(): View {
        val d = View(this)
        d.setBackgroundColor(Color.parseColor("#E5E5EA"))
        d.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1)
        return d
    }

    private fun text(t: String, size: Float, bold: Boolean): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(Color.parseColor("#1C1C1E"))
        if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
        v.setPadding(0, dp(2), 0, dp(2))
        return v
    }

    private fun button(t: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.setOnClickListener { onClick() }
        return b
    }

    private fun seek(min: Int, maxV: Int, value: Int, onChange: (Int) -> Unit): SeekBar {
        val s = SeekBar(this)
        s.max = maxV - min
        s.progress = value - min
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {}
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {
                onChange((sb?.progress ?: 0) + min)
            }
        })
        return s
    }
}
